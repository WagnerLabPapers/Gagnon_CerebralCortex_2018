subject_path = '/Volumes/group/awagner/sgagnon/SST/scripts/subjects_new.txt';
subids = textread(subject_path, '%s');

parfor iSub = 1:length(subids)
    hip_lanzar(subids{iSub});
end